// Arclen Website UI Kit — components.jsx
// Marketing landing page: arclen.app
// Fonts: Instrument Sans (display), IBM Plex Sans (body), IBM Plex Mono (data)

const { useState, useEffect } = React;

const WC = {
  base: '#09090B', surface: '#111116', elevated: '#18181F', subtle: '#1F1F28',
  border: '#27272F', borderSubtle: '#1C1C24',
  fg1: '#F0EEE9', fg2: '#8C8A99', fg3: '#50505A', fg4: '#35353E',
  accent: '#5AB8C4', accentHover: '#46A4B0', accentFg: '#7ACCD4',
};
const WD = "'Instrument Sans', system-ui, sans-serif";       // display
const WB = "'IBM Plex Sans', system-ui, sans-serif"; // body
const WM = "'IBM Plex Mono', monospace";             // mono

// ─── Layout helper ───────────────────────────────────────────────────────── //
const MaxW = ({ children, style = {} }) => (
  <div style={{ maxWidth: 1120, margin: '0 auto', padding: '0 40px', ...style }}>
    {children}
  </div>
);

// ─── Logo ─────────────────────────────────────────────────────────────────── //
const Logo = ({ dark = false, height = 28 }) => (
  <img
    src={dark ? '../../assets/logo-black.svg' : '../../assets/logo-white.svg'}
    alt="Arclen" style={{ height, width: 'auto', display: 'block' }}
  />
);

// ─── NavBar ───────────────────────────────────────────────────────────────── //
function NavBar() {
  const [scrolled, setScrolled] = useState(false);
  useEffect(() => {
    const fn = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', fn);
    return () => window.removeEventListener('scroll', fn);
  }, []);
  const lk = { fontFamily: WB, fontSize: 13, color: WC.fg3, cursor: 'pointer', padding: '4px 0', textDecoration: 'none' };
  return (
    <nav style={{
      position: 'sticky', top: 0, zIndex: 100, height: 60,
      background: WC.base, borderBottom: `1px solid ${scrolled ? WC.border : WC.borderSubtle}`,
      transition: 'border-color 200ms',
    }}>
      <MaxW style={{ height: '100%', display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 48 }}>
          <Logo />
          <div style={{ display: 'flex', gap: 32 }}>
            {['Product', 'Use cases', 'Pricing', 'Docs'].map(l => (
              <span key={l} style={lk}
                onMouseEnter={e => e.target.style.color = WC.fg1}
                onMouseLeave={e => e.target.style.color = WC.fg3}
              >{l}</span>
            ))}
          </div>
        </div>
        <div style={{ display: 'flex', gap: 10, alignItems: 'center' }}>
          <button style={{ background: 'none', border: 'none', color: WC.fg2, fontFamily: WB, fontSize: 13, cursor: 'pointer', padding: '6px 12px' }}>Log in</button>
          <button style={{ background: WC.accent, color: WC.base, border: 'none', fontFamily: WB, fontSize: 13, fontWeight: 500, padding: '8px 18px', borderRadius: 2, cursor: 'pointer' }}>Get access</button>
        </div>
      </MaxW>
    </nav>
  );
}

// ─── Terminal Demo ────────────────────────────────────────────────────────── //
function TerminalDemo() {
  const lines = [
    { t: 'cmd',  text: 'arclen exec pitch-book --deal=alpine' },
    { t: 'gap' },
    { t: 'kv',   k: 'deal  ', v: 'Project Alpine' },
    { t: 'kv',   k: 'files ', v: '14 loaded' },
    { t: 'kv',   k: 'task  ', v: 'Pitch book · v4' },
    { t: 'sep' },
    { t: 'step', text: 'Fetching comparable transactions', done: true },
    { t: 'step', text: 'Computing valuation range', done: true },
    { t: 'out',  text: 'EV range: €12.4M – €18.7M' },
    { t: 'gap' },
    { t: 'step', text: 'Building buyer analysis (23 targets)', done: true },
    { t: 'step', text: 'Updating Alpine_PitchBook_v4.pptx', done: true },
    { t: 'gap' },
    { t: 'done', text: '47 slides updated · 4.2s' },
    { t: 'cur' },
  ];
  const renderLine = (l, i) => {
    if (l.t === 'gap') return <div key={i} style={{ height: 8 }} />;
    if (l.t === 'sep') return <div key={i} style={{ height: 1, background: WC.borderSubtle, margin: '8px 0' }} />;
    if (l.t === 'cmd') return <div key={i} style={{ color: WC.fg2 }}><span style={{ color: WC.fg4, marginRight: 8 }}>$</span><span style={{ color: WC.fg1 }}>{l.text}</span></div>;
    if (l.t === 'kv')  return <div key={i} style={{ color: WC.fg4, paddingLeft: 16 }}><span style={{ display: 'inline-block', width: 56 }}>{l.k}</span><span style={{ color: WC.fg2 }}>{l.v}</span></div>;
    if (l.t === 'step') return (
      <div key={i} style={{ display: 'flex', justifyContent: 'space-between', paddingLeft: 16 }}>
        <span style={{ color: WC.fg3 }}>{l.text}</span>
        {l.done && <span style={{ color: '#5EBF8D' }}>✓</span>}
      </div>
    );
    if (l.t === 'out')  return <div key={i} style={{ color: WC.accentFg, paddingLeft: 16 }}>{l.text}</div>;
    if (l.t === 'done') return <div key={i} style={{ color: '#5EBF8D', fontWeight: 500 }}>{l.text}</div>;
    if (l.t === 'cur')  return <div key={i} style={{ color: WC.fg4 }}><span style={{ marginRight: 8 }}>$</span><span className="blink" style={{ display: 'inline-block', width: 7, height: 13, background: WC.accentFg, verticalAlign: 'text-bottom' }} /></div>;
    return null;
  };
  return (
    <div style={{ background: '#06060A', border: `1px solid ${WC.border}`, borderRadius: 2, overflow: 'hidden', fontFamily: WM, fontSize: 12.5, lineHeight: 1.65 }}>
      <div style={{ height: 38, background: WC.surface, borderBottom: `1px solid ${WC.border}`, display: 'flex', alignItems: 'center', padding: '0 14px', gap: 7 }}>
        {[0,1,2].map(i => <div key={i} style={{ width: 10, height: 10, borderRadius: '50%', background: WC.border }} />)}
        <span style={{ marginLeft: 8, fontSize: 11, color: WC.fg4, fontFamily: WB, letterSpacing: '0.02em' }}>VS Code — Terminal</span>
      </div>
      <div style={{ padding: '18px 22px' }}>{lines.map(renderLine)}</div>
    </div>
  );
}

// ─── Hero ─────────────────────────────────────────────────────────────────── //
function HeroSection() {
  return (
    <section style={{ padding: '112px 0 88px' }}>
      <MaxW>
        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 64, alignItems: 'center' }}>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 24 }}>
            <div style={{ fontFamily: WB, fontSize: 10, fontWeight: 500, letterSpacing: '0.12em', textTransform: 'uppercase', color: WC.fg4 }}>
              AI-powered M&amp;A execution
            </div>
            <h1 style={{ fontFamily: WD, fontSize: 66, fontWeight: 700, letterSpacing: '-0.03em', lineHeight: 0.93, color: WC.fg1, margin: 0 }}>
              Your deals,<br />automated.
            </h1>
            <p style={{ fontFamily: WB, fontSize: 15.5, lineHeight: 1.65, color: WC.fg2, maxWidth: 430, margin: 0 }}>
              Arclen turns VS Code into a full M&amp;A execution environment for boutique investment banks. Pitch books, valuations, buyer outreach — operated live inside your existing Office files.
            </p>
            <div style={{ display: 'flex', gap: 10, marginTop: 4 }}>
              <button style={{ background: WC.accent, color: WC.base, border: 'none', fontFamily: WB, fontSize: 13, fontWeight: 500, padding: '10px 22px', borderRadius: 2, cursor: 'pointer' }}>Request access</button>
              <button style={{ background: 'transparent', border: `1px solid ${WC.border}`, color: WC.fg1, fontFamily: WB, fontSize: 13, padding: '10px 22px', borderRadius: 2, cursor: 'pointer' }}>See it in action →</button>
            </div>
          </div>
          <TerminalDemo />
        </div>
      </MaxW>
    </section>
  );
}

// ─── Stats Strip ─────────────────────────────────────────────────────────── //
function StatsStrip() {
  const items = [
    { val: '3 Office apps', sub: 'Excel · Word · PowerPoint' },
    { val: 'Live COM automation', sub: 'Your files, not ours' },
    { val: 'Built for VS Code', sub: 'Runs alongside Claude Code' },
    { val: 'EU data residency', sub: 'Hosted in Frankfurt' },
  ];
  return (
    <div style={{ borderTop: `1px solid ${WC.border}`, borderBottom: `1px solid ${WC.border}` }}>
      <MaxW style={{ padding: 0 }}>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)' }}>
          {items.map((item, i) => (
            <div key={i} style={{ padding: '22px 28px', borderRight: i < 3 ? `1px solid ${WC.border}` : 'none' }}>
              <div style={{ fontFamily: WM, fontSize: 13, fontWeight: 500, color: WC.fg1, marginBottom: 4 }}>{item.val}</div>
              <div style={{ fontFamily: WB, fontSize: 10.5, letterSpacing: '0.04em', textTransform: 'uppercase', color: WC.fg4 }}>{item.sub}</div>
            </div>
          ))}
        </div>
      </MaxW>
    </div>
  );
}

// ─── Features ────────────────────────────────────────────────────────────── //
function FeaturesSection() {
  const features = [
    {
      title: 'Live Office automation',
      body: 'No generated files. Arclen writes directly to your Excel, PowerPoint and Word documents via native COM automation. The banker stays in control of every slide and cell.',
    },
    {
      title: 'Complete deal materials',
      body: 'Pitch books, information memoranda, financial datapacks, buyer process letters, valuation comps — built from your deal data and updated as it changes.',
    },
    {
      title: 'Structured buyer process',
      body: 'Build targeted buyer lists, draft NDAs and process letters, track IOI stages. The full sell-side outreach process, automated from first contact to indicative offer.',
    },
  ];
  return (
    <section style={{ padding: '88px 0', background: WC.surface, borderTop: `1px solid ${WC.border}`, borderBottom: `1px solid ${WC.border}` }}>
      <MaxW>
        <div style={{ marginBottom: 44 }}>
          <div style={{ fontFamily: WB, fontSize: 10, fontWeight: 500, letterSpacing: '0.1em', textTransform: 'uppercase', color: WC.fg4, marginBottom: 14 }}>Capabilities</div>
          <h2 style={{ fontFamily: WD, fontSize: 40, fontWeight: 600, letterSpacing: '-0.02em', color: WC.fg1, margin: 0, lineHeight: 1.05 }}>Everything a mandate needs.</h2>
        </div>
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 1, background: WC.border }}>
          {features.map((f, i) => (
            <div key={i} style={{ background: WC.surface, padding: '32px 28px' }}>
              <div style={{ fontFamily: WD, fontSize: 18, fontWeight: 500, color: WC.fg1, marginBottom: 12, letterSpacing: '-0.008em' }}>{f.title}</div>
              <p style={{ fontFamily: WB, fontSize: 13.5, lineHeight: 1.8, color: WC.fg2, margin: 0 }}>{f.body}</p>
            </div>
          ))}
        </div>
      </MaxW>
    </section>
  );
}

// ─── How It Works ────────────────────────────────────────────────────────── //
function HowItWorksSection() {
  const steps = [
    { n: '01', title: 'Connect your deal folder', body: 'Open your existing deal folder in VS Code. Arclen reads your files and builds deal context automatically — no configuration, no data entry.' },
    { n: '02', title: 'Describe the task', body: 'Tell Arclen what to build, in plain language. Pitch book, buyer list, valuation comp — Arclen maps the task to your deal data and Office files.' },
    { n: '03', title: 'Watch your Office files update', body: 'Arclen operates Excel, PowerPoint and Word in real-time via COM automation. Your files update as you watch. No exports, no copy-pasting.' },
  ];
  return (
    <section style={{ padding: '88px 0' }}>
      <MaxW>
        <div style={{ display: 'grid', gridTemplateColumns: '5fr 7fr', gap: 80, alignItems: 'start' }}>
          <div>
            <div style={{ fontFamily: WB, fontSize: 10, fontWeight: 500, letterSpacing: '0.1em', textTransform: 'uppercase', color: WC.fg4, marginBottom: 14 }}>How it works</div>
            <h2 style={{ fontFamily: WD, fontSize: 40, fontWeight: 600, letterSpacing: '-0.02em', color: WC.fg1, margin: 0, lineHeight: 1.05 }}>Your files.<br />Our automation.</h2>
            <p style={{ fontFamily: WB, fontSize: 13.5, lineHeight: 1.8, color: WC.fg2, marginTop: 20, marginBottom: 0 }}>
              Arclen does not create new documents. It operates the ones you already have — the pitch book template you've refined over 40 mandates, the financial model your associate built.
            </p>
          </div>
          <div>
            {steps.map((s, i) => (
              <div key={i} style={{ display: 'grid', gridTemplateColumns: '48px 1fr', gap: 20, padding: '28px 0', borderBottom: i < 2 ? `1px solid ${WC.borderSubtle}` : 'none' }}>
                <div style={{ fontFamily: WM, fontSize: 11.5, color: WC.accentFg, paddingTop: 3 }}>{s.n}</div>
                <div>
                  <div style={{ fontFamily: WD, fontSize: 17, fontWeight: 500, color: WC.fg1, marginBottom: 8, letterSpacing: '-0.005em' }}>{s.title}</div>
                  <p style={{ fontFamily: WB, fontSize: 13.5, lineHeight: 1.75, color: WC.fg2, margin: 0 }}>{s.body}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </MaxW>
    </section>
  );
}

// ─── CTA ─────────────────────────────────────────────────────────────────── //
function CTASection() {
  return (
    <section style={{ padding: '64px 0' }}>
      <MaxW>
        <div style={{ background: WC.surface, border: `1px solid ${WC.border}`, borderRadius: 2, padding: '56px 72px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', gap: 40 }}>
          <div>
            <h2 style={{ fontFamily: WD, fontSize: 34, fontWeight: 600, letterSpacing: '-0.02em', color: WC.fg1, margin: '0 0 12px', lineHeight: 1.1 }}>Built for firms that run real processes.</h2>
            <p style={{ fontFamily: WB, fontSize: 14, lineHeight: 1.7, color: WC.fg2, margin: 0, maxWidth: 480 }}>
              Arclen is available to boutique M&amp;A advisory firms in the EU and UK. Request access to the private beta.
            </p>
          </div>
          <button style={{ background: WC.accent, color: WC.base, border: 'none', fontFamily: WB, fontSize: 13, fontWeight: 500, padding: '12px 28px', borderRadius: 2, cursor: 'pointer', flexShrink: 0 }}>Request access</button>
        </div>
      </MaxW>
    </section>
  );
}

// ─── Footer ───────────────────────────────────────────────────────────────── //
function WebsiteFooter() {
  const cols = [
    { title: 'Product', links: ['Overview', 'Pricing', 'Changelog', 'Roadmap'] },
    { title: 'Resources', links: ['Documentation', 'API reference', 'VS Code guide', 'Security'] },
    { title: 'Company', links: ['About', 'Blog', 'Careers', 'Contact'] },
  ];
  return (
    <footer style={{ borderTop: `1px solid ${WC.borderSubtle}`, padding: '52px 0 36px' }}>
      <MaxW>
        <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr 1fr 1fr', gap: 40 }}>
          <div>
            <Logo height={26} />
            <p style={{ fontFamily: WB, fontSize: 13, color: WC.fg4, marginTop: 16, lineHeight: 1.6, maxWidth: 250, marginBottom: 0 }}>AI-powered M&amp;A workflow platform for boutique investment banks.</p>
          </div>
          {cols.map(col => (
            <div key={col.title}>
              <div style={{ fontFamily: WB, fontSize: 10, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase', color: WC.fg4, marginBottom: 16 }}>{col.title}</div>
              <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                {col.links.map(l => <span key={l} style={{ fontFamily: WB, fontSize: 13, color: WC.fg3, cursor: 'pointer' }}>{l}</span>)}
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 44, paddingTop: 20, borderTop: `1px solid ${WC.borderSubtle}`, display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: WB, fontSize: 12, color: WC.fg4 }}>© 2026 Arclen. All rights reserved.</span>
          <div style={{ display: 'flex', gap: 24 }}>
            {['Privacy policy', 'Terms of service'].map(l => <span key={l} style={{ fontFamily: WB, fontSize: 12, color: WC.fg4, cursor: 'pointer' }}>{l}</span>)}
          </div>
        </div>
      </MaxW>
    </footer>
  );
}

// ─── Root ─────────────────────────────────────────────────────────────────── //
function Website() {
  return (
    <div style={{ background: WC.base, minHeight: '100vh' }}>
      <style>{`@keyframes blink { 0%,100%{opacity:1}50%{opacity:0} } .blink{animation:blink 1s step-end infinite} *{box-sizing:border-box;margin:0;padding:0} body{background:${WC.base}}`}</style>
      <NavBar />
      <HeroSection />
      <StatsStrip />
      <FeaturesSection />
      <HowItWorksSection />
      <CTASection />
      <WebsiteFooter />
    </div>
  );
}

Object.assign(window, { Website });
