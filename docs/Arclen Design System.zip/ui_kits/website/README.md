# Arclen Website UI Kit

Marketing landing page prototype for `arclen.app`.

## What's here
- `index.html` — Entry point, loads React + Babel + fonts
- `components.jsx` — All page sections as React components

## Sections implemented
1. **NavBar** — Sticky navigation with logo, links, CTA buttons
2. **HeroSection** — 2-column: headline + interactive terminal demo
3. **StatsStrip** — 4-column horizontal authority strip
4. **FeaturesSection** — 3-card capability grid
5. **HowItWorksSection** — 2-column: context + numbered 3-step process
6. **CTASection** — Full-width CTA card with request access
7. **WebsiteFooter** — 4-column footer with logo and links

## Design notes
- Dark mode primary. Background `#09090B`, surface sections `#111116`.
- Instrument Sans 700 for headlines (66px hero), IBM Plex Sans for body.
- Arctic accent (`#5AB8C4`) used only on primary CTA buttons.
- No gradients, no rounded shapes, max border-radius 2px.
- Grid layout with 1px `#27272F` borders as structural dividers.
- Copy follows brand voice: direct, no fluff, sentence case.

## Assets used
- `../../assets/logo-white.svg` — Wordmark
- `../../assets/logo-black.svg` — Dark wordmark (footer light fallback)
