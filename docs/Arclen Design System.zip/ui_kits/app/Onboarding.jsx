// Arclen Onboarding — VS Codium fork first-launch flow
// 6 steps: Welcome → Claude → Workspace → Deal folder → Office → Ready

const { useState } = React;

const C = {
  bg: '#09090B', surface: '#111116', elevated: '#18181F', subtle: '#1F1F28', inset: '#06060A',
  border: '#27272F', borderSubtle: '#1C1C24', borderStrong: '#3A3A46',
  fg1: '#F0EEE9', fg2: '#8C8A99', fg3: '#50505A', fg4: '#35353E',
  accent: '#5AB8C4', accentHover: '#46A4B0', accentFg: '#7ACCD4', accentSubtle: '#081618', accentMuted: '#3A8A94',
  green: '#4EA87A', greenFg: '#5EBF8D', greenSubtle: '#0B1F15',
  red: '#D95858', redFg: '#E86A6A',
};
const ED = "'Instrument Sans', system-ui, sans-serif";
const SN = "'IBM Plex Sans', system-ui, sans-serif";
const MN = "'IBM Plex Mono', monospace";

const STEPS = [
  { id: 'welcome',   label: 'Welcome' },
  { id: 'claude',    label: 'Claude' },
  { id: 'workspace', label: 'Workspace' },
  { id: 'folder',    label: 'Deal folder' },
  { id: 'office',    label: 'Office' },
  { id: 'ready',     label: 'Ready' },
];

// ─── Window chrome ────────────────────────────────────────────────────────── //
function WindowChrome({ children }) {
  return (
    <div style={{ width: '100%', height: '100%', display: 'flex', flexDirection: 'column', background: C.bg, overflow: 'hidden' }}>
      <div style={{ height: 32, background: C.elevated, borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', padding: '0 12px', gap: 8, flexShrink: 0 }}>
        <div style={{ display: 'flex', gap: 7 }}>
          {['#FF5F57', '#FEBC2E', '#28C840'].map((c, i) => (
            <div key={i} style={{ width: 11, height: 11, borderRadius: '50%', background: c, opacity: 0.95 }} />
          ))}
        </div>
        <div style={{ flex: 1, textAlign: 'center', fontFamily: SN, fontSize: 11, color: C.fg4, letterSpacing: '0.02em' }}>
          Arclen — Welcome
        </div>
        <div style={{ width: 50 }} />
      </div>
      <div style={{ flex: 1, overflow: 'hidden' }}>{children}</div>
    </div>
  );
}

// ─── Step indicator (top) ────────────────────────────────────────────────── //
function StepIndicator({ current }) {
  return (
    <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 56, fontFamily: SN }}>
      {STEPS.map((step, i) => {
        const done = i < current;
        const active = i === current;
        return (
          <React.Fragment key={step.id}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
              <div style={{
                width: 22, height: 22, borderRadius: 2,
                background: active ? C.accent : (done ? C.accentSubtle : 'transparent'),
                border: `1px solid ${active ? C.accent : (done ? C.accentMuted : C.border)}`,
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 11, fontWeight: 500, fontFamily: MN,
                color: active ? C.bg : (done ? C.accentFg : C.fg3),
                transition: 'all 200ms',
              }}>
                {done ? (
                  <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <polyline points="20 6 9 17 4 12"/>
                  </svg>
                ) : (i + 1)}
              </div>
              <span style={{ fontSize: 11, color: active ? C.fg1 : (done ? C.fg2 : C.fg4), fontWeight: active ? 500 : 400 }}>{step.label}</span>
            </div>
            {i < STEPS.length - 1 && (
              <div style={{ flex: '0 0 24px', height: 1, background: done ? C.accentMuted : C.borderSubtle }} />
            )}
          </React.Fragment>
        );
      })}
    </div>
  );
}

// ─── Eyebrow + heading ──────────────────────────────────────────────────── //
function StepHeading({ eyebrow, title, subtitle }) {
  return (
    <div style={{ marginBottom: 40 }}>
      {eyebrow && (
        <div style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, letterSpacing: '0.12em', textTransform: 'uppercase', color: C.fg4, marginBottom: 14 }}>{eyebrow}</div>
      )}
      <h1 style={{ fontFamily: ED, fontSize: 38, fontWeight: 600, letterSpacing: '-0.025em', color: C.fg1, lineHeight: 1.05, margin: 0 }}>{title}</h1>
      {subtitle && (
        <p style={{ fontFamily: SN, fontSize: 14.5, lineHeight: 1.7, color: C.fg2, marginTop: 16, maxWidth: 560 }}>{subtitle}</p>
      )}
    </div>
  );
}

// ─── Form field ──────────────────────────────────────────────────────────── //
function Field({ label, hint, children }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: 6, marginBottom: 18 }}>
      <div style={{ fontFamily: SN, fontSize: 11, fontWeight: 500, color: C.fg2 }}>{label}</div>
      {children}
      {hint && <div style={{ fontFamily: SN, fontSize: 11, color: C.fg4, lineHeight: 1.5 }}>{hint}</div>}
    </div>
  );
}

function TextInput({ value, onChange, placeholder, mono }) {
  return (
    <input
      type="text" value={value} onChange={e => onChange(e.target.value)} placeholder={placeholder}
      style={{
        background: C.inset, border: `1px solid ${C.border}`, borderRadius: 2,
        color: C.fg1, fontFamily: mono ? MN : SN, fontSize: 13,
        padding: '9px 12px', outline: 'none', width: '100%',
        transition: 'border-color 120ms',
      }}
      onFocus={e => e.target.style.borderColor = C.accent}
      onBlur={e => e.target.style.borderColor = C.border}
    />
  );
}

function SelectInput({ value, onChange, options }) {
  return (
    <div style={{ position: 'relative' }}>
      <select value={value} onChange={e => onChange(e.target.value)} style={{
        background: C.inset, border: `1px solid ${C.border}`, borderRadius: 2,
        color: C.fg1, fontFamily: SN, fontSize: 13,
        padding: '9px 32px 9px 12px', outline: 'none', width: '100%',
        appearance: 'none', cursor: 'pointer',
      }}>
        {options.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
      </select>
      <svg style={{ position: 'absolute', right: 11, top: '50%', transform: 'translateY(-50%)', pointerEvents: 'none', color: C.fg3 }} width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5">
        <path d="M6 9l6 6 6-6"/>
      </svg>
    </div>
  );
}

// ─── Step 1: Welcome ─────────────────────────────────────────────────────── //
function StepWelcome({ next }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', maxWidth: 600 }}>
      <img src="../../assets/favicon-white-180x180.svg" alt="" style={{ width: 56, height: 56, marginBottom: 36 }} />
      <h1 style={{ fontFamily: ED, fontSize: 52, fontWeight: 600, letterSpacing: '-0.03em', color: C.fg1, lineHeight: 1.02, margin: '0 0 20px' }}>
        Welcome to Arclen.
      </h1>
      <p style={{ fontFamily: SN, fontSize: 16, lineHeight: 1.7, color: C.fg2, margin: 0, maxWidth: 540 }}>
        An IDE for M&amp;A advisory. Built on VS Codium. Pitch books, valuations, buyer outreach — operated live inside your Excel, PowerPoint and Word files.
      </p>
      <p style={{ fontFamily: SN, fontSize: 14, lineHeight: 1.7, color: C.fg3, marginTop: 14, marginBottom: 0, maxWidth: 540 }}>
        This setup takes about 3 minutes. You'll connect Claude, point Arclen at your deal folder, and enable Office integrations.
      </p>
      <div style={{ display: 'flex', gap: 10, marginTop: 44 }}>
        <button onClick={next} style={{ background: C.accent, color: C.bg, border: 'none', fontFamily: SN, fontSize: 13, fontWeight: 500, padding: '11px 28px', borderRadius: 2, cursor: 'pointer' }}>
          Get started
        </button>
        <button style={{ background: 'transparent', color: C.fg2, border: `1px solid ${C.border}`, fontFamily: SN, fontSize: 13, padding: '11px 22px', borderRadius: 2, cursor: 'pointer' }}>
          Restore from backup
        </button>
      </div>
    </div>
  );
}

// ─── Step 2: Claude ──────────────────────────────────────────────────────── //
function StepClaude({ next, back }) {
  const [key, setKey] = useState('');
  return (
    <>
      <StepHeading
        eyebrow="Step 2 · Claude"
        title="Connect your Claude account."
        subtitle="Arclen runs on Claude Code. You'll need an API key from console.anthropic.com. Your key stays local — Arclen never proxies through our servers."
      />
      <div style={{ maxWidth: 520 }}>
        <Field label="Anthropic API key" hint="Paste your sk-ant-… key. Stored in macOS Keychain / Windows Credential Manager.">
          <TextInput value={key} onChange={setKey} placeholder="sk-ant-..." mono />
        </Field>
        <div style={{ background: C.surface, border: `1px solid ${C.borderSubtle}`, borderRadius: 2, padding: '14px 16px', marginTop: 8, display: 'flex', alignItems: 'flex-start', gap: 12 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke={C.accentFg} strokeWidth="1.5" style={{ marginTop: 2, flexShrink: 0 }}>
            <path d="M12 2L3 7v5c0 5 3.8 9.4 9 10 5.2-.6 9-5 9-10V7l-9-5z"/>
          </svg>
          <div>
            <div style={{ fontFamily: SN, fontSize: 12, fontWeight: 500, color: C.fg1, marginBottom: 4 }}>Local-first by design.</div>
            <div style={{ fontFamily: SN, fontSize: 12, lineHeight: 1.6, color: C.fg3 }}>
              Your deal data and API key never leave your machine. All Claude requests are made directly from this client to Anthropic's API.
            </div>
          </div>
        </div>
      </div>
      <NavButtons back={back} next={next} canContinue={key.startsWith('sk-')} />
    </>
  );
}

// ─── Step 3: Workspace ───────────────────────────────────────────────────── //
function StepWorkspace({ next, back }) {
  const [firm, setFirm] = useState('');
  const [region, setRegion] = useState('eu-fra');
  const [size, setSize] = useState('boutique');
  return (
    <>
      <StepHeading
        eyebrow="Step 3 · Workspace"
        title="Set up your firm."
        subtitle="Used to brand outputs and route data to your region. You can change all of this later."
      />
      <div style={{ maxWidth: 520 }}>
        <Field label="Firm name" hint="Appears on pitch book covers, process letters, and CIMs.">
          <TextInput value={firm} onChange={setFirm} placeholder="e.g. Mercier &amp; Partners" />
        </Field>
        <Field label="Data region" hint="Where Arclen caches deal context. Cannot be changed once data is written.">
          <SelectInput value={region} onChange={setRegion} options={[
            { value: 'eu-fra', label: 'EU — Frankfurt (recommended)' },
            { value: 'eu-par', label: 'EU — Paris' },
            { value: 'uk-lon', label: 'UK — London' },
            { value: 'ch-zur', label: 'Switzerland — Zürich' },
          ]} />
        </Field>
        <Field label="Firm size">
          <div style={{ display: 'flex', gap: 8 }}>
            {[
              { v: 'boutique', l: 'Boutique', sub: '1–25' },
              { v: 'midmarket', l: 'Mid-market', sub: '26–100' },
              { v: 'enterprise', l: 'Large', sub: '100+' },
            ].map(o => (
              <button key={o.v} onClick={() => setSize(o.v)} style={{
                flex: 1, background: size === o.v ? C.accentSubtle : C.inset,
                border: `1px solid ${size === o.v ? C.accent : C.border}`,
                borderRadius: 2, cursor: 'pointer', padding: '10px 12px', textAlign: 'left', display: 'flex', flexDirection: 'column', gap: 2,
                transition: 'all 120ms',
              }}>
                <div style={{ fontFamily: SN, fontSize: 12, fontWeight: 500, color: size === o.v ? C.accentFg : C.fg1 }}>{o.l}</div>
                <div style={{ fontFamily: MN, fontSize: 10, color: C.fg4 }}>{o.sub} bankers</div>
              </button>
            ))}
          </div>
        </Field>
      </div>
      <NavButtons back={back} next={next} canContinue={firm.length > 1} />
    </>
  );
}

// ─── Step 4: Deal folder ─────────────────────────────────────────────────── //
function StepFolder({ next, back }) {
  const [picked, setPicked] = useState(false);
  return (
    <>
      <StepHeading
        eyebrow="Step 4 · Deal folder"
        title="Connect your deal folder."
        subtitle="Arclen reads your existing files in place — pitch books, models, buyer lists. Nothing is copied or moved."
      />
      <div style={{ maxWidth: 560 }}>
        {!picked ? (
          <div style={{ background: C.surface, border: `1.5px dashed ${C.border}`, borderRadius: 2, padding: '38px 24px', textAlign: 'center', cursor: 'pointer' }} onClick={() => setPicked(true)}>
            <svg width="32" height="32" viewBox="0 0 24 24" fill="none" stroke={C.fg3} strokeWidth="1.3" style={{ display: 'block', margin: '0 auto 14px' }}>
              <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
            </svg>
            <div style={{ fontFamily: SN, fontSize: 14, fontWeight: 500, color: C.fg1, marginBottom: 4 }}>Choose deal folder</div>
            <div style={{ fontFamily: SN, fontSize: 12, color: C.fg3 }}>Browse your filesystem · Drag &amp; drop a folder</div>
          </div>
        ) : (
          <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 2, padding: '14px 16px' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke={C.accentFg} strokeWidth="1.5"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/></svg>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: MN, fontSize: 12, color: C.fg1 }}>~/Documents/Deals/</div>
                <div style={{ fontFamily: SN, fontSize: 11, color: C.fg4 }}>4 deal folders found</div>
              </div>
              <span style={{ background: C.greenSubtle, color: C.greenFg, border: `1px solid ${C.green}`, fontFamily: SN, fontSize: 10, fontWeight: 500, padding: '2px 7px', borderRadius: 2 }}>Connected</span>
            </div>
            <div style={{ borderTop: `1px solid ${C.borderSubtle}`, paddingTop: 12, display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8 }}>
              {[
                ['Project Alpine',   'Industrial · IOI'],
                ['Project Rhine',    'Tech · Prep'],
                ['Project Elbe',     'Services · Signed'],
                ['Project Danube',   'Healthcare · Closed'],
              ].map(([name, meta]) => (
                <div key={name} style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '5px 8px', background: C.inset, borderRadius: 2 }}>
                  <div style={{ width: 5, height: 5, borderRadius: '50%', background: C.accent }} />
                  <div style={{ fontFamily: SN, fontSize: 12, color: C.fg1, fontWeight: 500 }}>{name}</div>
                  <div style={{ fontFamily: SN, fontSize: 10, color: C.fg4, marginLeft: 'auto' }}>{meta}</div>
                </div>
              ))}
            </div>
            <div style={{ marginTop: 14, paddingTop: 12, borderTop: `1px solid ${C.borderSubtle}`, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontFamily: SN, fontSize: 11, color: C.fg3 }}>Found <span style={{ color: C.fg1, fontFamily: MN }}>247 files</span> across <span style={{ color: C.fg1, fontFamily: MN }}>4 deals</span></div>
              <button onClick={() => setPicked(false)} style={{ background: 'transparent', border: 'none', fontFamily: SN, fontSize: 11, color: C.accentFg, cursor: 'pointer' }}>Change folder</button>
            </div>
          </div>
        )}
        <div style={{ marginTop: 18, fontFamily: SN, fontSize: 11, lineHeight: 1.65, color: C.fg4 }}>
          Tip: Choose your top-level deals folder. Arclen will scan subfolders matching common patterns (e.g. <span style={{ fontFamily: MN, color: C.fg2 }}>Project_*</span>, <span style={{ fontFamily: MN, color: C.fg2 }}>YYYY-MM_*</span>).
        </div>
      </div>
      <NavButtons back={back} next={next} canContinue={picked} />
    </>
  );
}

// ─── Step 5: Office integration ──────────────────────────────────────────── //
function StepOffice({ next, back }) {
  const [enabled, setEnabled] = useState({ excel: true, ppt: true, word: true });
  const apps = [
    { id: 'excel', name: 'Excel',       icon: 'X', color: '#1F6E43', desc: 'Models, datapacks, buyer lists, valuation comps' },
    { id: 'ppt',   name: 'PowerPoint',  icon: 'P', color: '#A8401D', desc: 'Pitch books, teasers, IM, board materials' },
    { id: 'word',  name: 'Word',        icon: 'W', color: '#1A4D8A', desc: 'CIMs, process letters, NDAs, engagement letters' },
  ];
  return (
    <>
      <StepHeading
        eyebrow="Step 5 · Office"
        title="Enable Office automation."
        subtitle="Arclen operates Excel, PowerPoint and Word via native COM. The apps stay open on your desktop and update in real-time as Arclen runs."
      />
      <div style={{ maxWidth: 560, display: 'flex', flexDirection: 'column', gap: 10 }}>
        {apps.map(app => {
          const on = enabled[app.id];
          return (
            <div key={app.id} style={{ background: C.surface, border: `1px solid ${on ? C.accentMuted : C.border}`, borderRadius: 2, padding: '14px 18px', display: 'flex', alignItems: 'center', gap: 16 }}>
              <div style={{ width: 36, height: 36, borderRadius: 2, background: app.color, display: 'flex', alignItems: 'center', justifyContent: 'center', fontFamily: ED, fontSize: 18, fontWeight: 600, color: '#fff', flexShrink: 0 }}>{app.icon}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontFamily: SN, fontSize: 13, fontWeight: 500, color: C.fg1 }}>Microsoft {app.name}</div>
                <div style={{ fontFamily: SN, fontSize: 11.5, color: C.fg3, marginTop: 2 }}>{app.desc}</div>
              </div>
              <button onClick={() => setEnabled(e => ({ ...e, [app.id]: !e[app.id] }))} style={{
                width: 36, height: 20, borderRadius: 10, border: 'none',
                background: on ? C.accent : C.subtle, position: 'relative', cursor: 'pointer',
                transition: 'background 120ms', flexShrink: 0,
              }}>
                <div style={{
                  position: 'absolute', top: 2, left: on ? 18 : 2,
                  width: 16, height: 16, borderRadius: '50%',
                  background: on ? C.bg : C.fg3, transition: 'left 120ms',
                }} />
              </button>
            </div>
          );
        })}
        <div style={{ marginTop: 8, padding: '12px 14px', background: C.inset, border: `1px solid ${C.borderSubtle}`, borderRadius: 2, display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={C.fg3} strokeWidth="1.5" style={{ marginTop: 2, flexShrink: 0 }}>
            <circle cx="12" cy="12" r="10"/><path d="M12 8v4M12 16h.01"/>
          </svg>
          <div style={{ fontFamily: SN, fontSize: 11.5, lineHeight: 1.6, color: C.fg3 }}>
            Office automation requires Microsoft Office 365 on Windows or macOS. Arclen uses your local Office license — no separate subscription needed.
          </div>
        </div>
      </div>
      <NavButtons back={back} next={next} canContinue={Object.values(enabled).some(Boolean)} />
    </>
  );
}

// ─── Step 6: Ready ──────────────────────────────────────────────────────── //
function StepReady({ back }) {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-start', maxWidth: 580 }}>
      <div style={{ width: 48, height: 48, borderRadius: 2, background: C.accentSubtle, border: `1px solid ${C.accentMuted}`, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 32 }}>
        <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke={C.accentFg} strokeWidth="2">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
      </div>
      <h1 style={{ fontFamily: ED, fontSize: 44, fontWeight: 600, letterSpacing: '-0.025em', color: C.fg1, lineHeight: 1.05, margin: '0 0 18px' }}>
        You're ready.
      </h1>
      <p style={{ fontFamily: SN, fontSize: 15, lineHeight: 1.7, color: C.fg2, margin: 0, maxWidth: 520 }}>
        Open any deal folder and Arclen will pick it up. Use <kbd style={{ fontFamily: MN, fontSize: 12, background: C.inset, border: `1px solid ${C.border}`, borderRadius: 2, padding: '2px 6px', color: C.fg1 }}>⌘ K</kbd> to run a task, or type a command in the AI panel at the bottom.
      </p>

      <div style={{ marginTop: 36, marginBottom: 36, display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 1, background: C.border, border: `1px solid ${C.border}`, borderRadius: 2, overflow: 'hidden', width: '100%' }}>
        {[
          ['Deals connected',   '4'],
          ['Files indexed',     '247'],
          ['Office apps',       '3 enabled'],
        ].map(([label, val]) => (
          <div key={label} style={{ background: C.surface, padding: '14px 16px' }}>
            <div style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, marginBottom: 6 }}>{label}</div>
            <div style={{ fontFamily: MN, fontSize: 16, color: C.accentFg, fontWeight: 500 }}>{val}</div>
          </div>
        ))}
      </div>

      <div style={{ display: 'flex', gap: 10 }}>
        <button onClick={() => alert('Would open Project Alpine')} style={{ background: C.accent, color: C.bg, border: 'none', fontFamily: SN, fontSize: 13, fontWeight: 500, padding: '11px 28px', borderRadius: 2, cursor: 'pointer' }}>
          Open Project Alpine
        </button>
        <button style={{ background: 'transparent', color: C.fg2, border: `1px solid ${C.border}`, fontFamily: SN, fontSize: 13, padding: '11px 22px', borderRadius: 2, cursor: 'pointer' }}>
          See the docs
        </button>
      </div>
    </div>
  );
}

// ─── Nav buttons (back / continue) ──────────────────────────────────────── //
function NavButtons({ back, next, canContinue }) {
  return (
    <div style={{ display: 'flex', gap: 10, marginTop: 44 }}>
      <button onClick={next} disabled={!canContinue} style={{
        background: canContinue ? C.accent : C.subtle,
        color: canContinue ? C.bg : C.fg3,
        border: 'none', fontFamily: SN, fontSize: 13, fontWeight: 500,
        padding: '11px 28px', borderRadius: 2, cursor: canContinue ? 'pointer' : 'not-allowed',
        transition: 'background 120ms',
      }}>
        Continue
      </button>
      <button onClick={back} style={{
        background: 'transparent', color: C.fg2, border: `1px solid ${C.border}`,
        fontFamily: SN, fontSize: 13, padding: '11px 22px', borderRadius: 2, cursor: 'pointer',
      }}>
        Back
      </button>
    </div>
  );
}

// ─── Onboarding root ─────────────────────────────────────────────────────── //
function Onboarding() {
  const [step, setStep] = useState(0);
  const next = () => setStep(s => Math.min(s + 1, STEPS.length - 1));
  const back = () => setStep(s => Math.max(s - 1, 0));

  return (
    <WindowChrome>
      <div style={{ height: '100%', overflowY: 'auto', display: 'flex', justifyContent: 'center', padding: '52px 64px 80px' }}>
        <div style={{ width: '100%', maxWidth: 680, display: 'flex', flexDirection: 'column' }}>
          {step > 0 && <StepIndicator current={step} />}
          {step === 0 && <StepWelcome   next={next} />}
          {step === 1 && <StepClaude    next={next} back={back} />}
          {step === 2 && <StepWorkspace next={next} back={back} />}
          {step === 3 && <StepFolder    next={next} back={back} />}
          {step === 4 && <StepOffice    next={next} back={back} />}
          {step === 5 && <StepReady     back={back} />}
        </div>
      </div>
    </WindowChrome>
  );
}

Object.assign(window, { Onboarding });
