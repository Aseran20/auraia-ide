// Arclen App UI Kit — components.jsx
// Deal execution interface: VS Code webview / standalone app
// Fonts: IBM Plex Sans (UI), IBM Plex Mono (data/code)

const { useState, useRef, useEffect } = React;

const C = {
  bg: '#09090B', surface: '#111116', elevated: '#18181F', subtle: '#1F1F28',
  border: '#27272F', borderSubtle: '#1C1C24',
  fg1: '#F0EEE9', fg2: '#8C8A99', fg3: '#50505A', fg4: '#35353E',
  accent: '#5AB8C4', accentHover: '#46A4B0', accentFg: '#7ACCD4', accentSubtle: '#081618',
  green: '#4EA87A', greenFg: '#5EBF8D', greenSubtle: '#0B1F15',
  red: '#D95858',   redFg: '#E86A6A',   redSubtle: '#1F0B0B',
  yellow: '#D4B84A', yellowFg: '#E5CC66', yellowSubtle: '#1C180A',
  blue: '#5B8FD4',   blueFg: '#7AAAE0',   blueSubtle: '#0B1220',
};
const SN = "'IBM Plex Sans', system-ui, sans-serif";
const MN = "'IBM Plex Mono', monospace";

// ─── Data ─────────────────────────────────────────────────────────────────── //
const DEALS = [
  { id: 'alpine',  name: 'Project Alpine',  stage: 'IOI',         dot: C.accent },
  { id: 'rhine',   name: 'Project Rhine',   stage: 'Preparation', dot: C.blue },
  { id: 'elbe',    name: 'Project Elbe',    stage: 'Signed',      dot: C.green },
  { id: 'danube',  name: 'Project Danube',  stage: 'Closed',      dot: C.fg4 },
];

const BUYERS = [
  { name: 'Rheinmetall Industrials', country: 'DE', type: 'Strategic',    ev: '€142.3M', status: 'ioi',         last: '2d ago' },
  { name: 'Nordic Capital',          country: 'SE', type: 'PE Fund',      ev: '—',       status: 'nda',         last: '1d ago' },
  { name: 'Bridgepoint',             country: 'GB', type: 'PE Fund',      ev: '—',       status: 'nda-pending', last: '3d ago' },
  { name: 'Ahlström Capital',        country: 'FI', type: 'Family office', ev: '€34.1M', status: 'contacted',   last: '5d ago' },
  { name: 'Adecco Group',            country: 'CH', type: 'Strategic',    ev: '€89.7M',  status: 'declined',    last: '1w ago' },
  { name: 'Holcim Group',            country: 'CH', type: 'Strategic',    ev: '€76.2M',  status: 'contacted',   last: '4d ago' },
];

const DOCS = [
  { name: 'Alpine_PitchBook_v4.pptx', ext: 'pptx', meta: '47 slides',    status: 'updated', time: '2h ago' },
  { name: 'Alpine_CIM_v3.docx',       ext: 'docx', meta: '32 pages',     status: 'updated', time: '1d ago' },
  { name: 'Buyer_Universe_v2.xlsx',   ext: 'xlsx', meta: '89 contacts',   status: 'updated', time: '4h ago' },
  { name: 'ValuationBridge_v2.xlsx',  ext: 'xlsx', meta: 'DCF + comps',  status: 'updated', time: '2d ago' },
  { name: 'Process_Letter_v1.docx',   ext: 'docx', meta: 'Draft',        status: 'draft',   time: '3h ago' },
  { name: 'NDA_Template.docx',        ext: 'docx', meta: 'Standard NDA', status: 'stable',  time: '1w ago' },
];

const AI_LOG = [
  { time: '14:32', cmd: 'arclen exec pitch-book',            result: 'Pitch book updated · 47 slides · 4.2s',       ok: true },
  { time: '10:15', cmd: 'arclen expand buyers --sector=ind', result: '6 new targets added to buyer universe',        ok: true },
  { time: '09:44', cmd: 'arclen update nda-tracker',         result: 'Nordic Capital: NDA signed',                   ok: true },
  { time: 'Yest',  cmd: 'arclen refresh comps',              result: '12 comparable transactions updated',           ok: true },
  { time: 'Yest',  cmd: 'arclen rewrite cim --section=mgmt', result: 'CIM management section rewritten · 4 pages',  ok: true },
];

const STATUS_CFG = {
  'ioi':         { label: 'IOI received', bg: C.blueSubtle,   fg: C.blueFg,   border: C.blue },
  'nda':         { label: 'NDA signed',   bg: C.greenSubtle,  fg: C.greenFg,  border: C.green },
  'nda-pending': { label: 'NDA pending',  bg: C.yellowSubtle, fg: C.yellowFg, border: C.yellow },
  'contacted':   { label: 'Contacted',    bg: C.subtle,       fg: C.fg2,      border: C.border },
  'declined':    { label: 'Declined',     bg: C.redSubtle,    fg: C.redFg,    border: C.red },
};

// ─── Shared atoms ─────────────────────────────────────────────────────────── //
const Badge = ({ status }) => {
  const s = STATUS_CFG[status] || { label: status, bg: C.subtle, fg: C.fg2, border: C.border };
  return (
    <span style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, padding: '1px 6px', borderRadius: 2, background: s.bg, color: s.fg, border: `1px solid ${s.border}`, whiteSpace: 'nowrap' }}>
      {s.label}
    </span>
  );
};

const DocBadge = ({ status }) => {
  const cfg = {
    updated: { bg: C.accentSubtle, fg: C.accentFg, border: '#3A8A94' },
    draft:   { bg: C.blueSubtle,   fg: C.blueFg,   border: C.blue },
    stable:  { bg: C.subtle,       fg: C.fg3,      border: C.border },
  }[status] || {};
  return (
    <span style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, padding: '1px 6px', borderRadius: 2, background: cfg.bg, color: cfg.fg, border: `1px solid ${cfg.border}` }}>{status}</span>
  );
};

const FileIcon = ({ color = C.fg4 }) => (
  <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke={color} strokeWidth="1.5">
    <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
  </svg>
);

// ─── App Nav ──────────────────────────────────────────────────────────────── //
function AppNav({ deal }) {
  const stageColors = { 'IOI': C.accentFg, 'Preparation': C.blueFg, 'Signed': C.greenFg, 'Closed': C.fg3 };
  return (
    <div style={{ height: 44, background: C.elevated, borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px', flexShrink: 0 }}>
      <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
        <img src="../../assets/favicon-white-180x180.svg" style={{ width: 20, height: 20, opacity: 0.85 }} alt="" />
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, fontFamily: SN, fontSize: 12 }}>
          <span style={{ color: C.fg4 }}>Arclen</span>
          <span style={{ color: C.fg4 }}>/</span>
          <span style={{ color: C.fg1, fontWeight: 500 }}>{deal.name}</span>
          <span style={{ marginLeft: 4, fontFamily: SN, fontSize: 10, color: stageColors[deal.stage] || C.fg2 }}>· {deal.stage}</span>
        </div>
      </div>
      <div style={{ display: 'flex', gap: 8, alignItems: 'center' }}>
        <button style={{ background: C.accent, color: C.bg, border: 'none', fontFamily: SN, fontSize: 11, fontWeight: 500, padding: '5px 13px', borderRadius: 2, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          Run
        </button>
        <button style={{ background: 'transparent', color: C.fg2, border: `1px solid ${C.border}`, fontFamily: SN, fontSize: 11, padding: '5px 13px', borderRadius: 2, cursor: 'pointer' }}>New document</button>
        <div style={{ width: 28, height: 28, display: 'flex', alignItems: 'center', justifyContent: 'center', cursor: 'pointer', color: C.fg3, borderRadius: 2 }}>
          <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>
        </div>
      </div>
    </div>
  );
}

// ─── Sidebar ──────────────────────────────────────────────────────────────── //
function AppSidebar({ activeDeal, onSelect }) {
  return (
    <div style={{ width: 216, flexShrink: 0, background: C.surface, borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', overflowY: 'auto' }}>
      <div style={{ padding: '14px 12px 6px' }}>
        <div style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN }}>Deals</div>
      </div>
      {DEALS.map(deal => (
        <div key={deal.id} onClick={() => onSelect(deal.id)} style={{ height: 38, display: 'flex', alignItems: 'center', gap: 9, padding: '0 12px', cursor: 'pointer', background: activeDeal === deal.id ? C.subtle : 'transparent', borderLeft: `2px solid ${activeDeal === deal.id ? C.accent : 'transparent'}`, transition: 'background 100ms' }}>
          <div style={{ width: 6, height: 6, borderRadius: '50%', background: deal.dot, flexShrink: 0 }} />
          <span style={{ flex: 1, fontSize: 12, fontFamily: SN, fontWeight: activeDeal === deal.id ? 500 : 400, color: activeDeal === deal.id ? C.fg1 : C.fg2, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{deal.name}</span>
          <span style={{ fontSize: 10, fontFamily: SN, color: activeDeal === deal.id ? C.accentFg : C.fg4, flexShrink: 0 }}>{deal.stage}</span>
        </div>
      ))}
      <div style={{ height: 1, background: C.borderSubtle, margin: '8px 12px' }} />
      <div style={{ padding: '6px 12px' }}>
        <div style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN }}>Files</div>
      </div>
      {DOCS.slice(0, 4).map((doc, i) => (
        <div key={i} style={{ height: 30, display: 'flex', alignItems: 'center', gap: 7, padding: '0 12px', cursor: 'pointer' }}>
          <FileIcon />
          <span style={{ fontSize: 11, fontFamily: SN, color: C.fg3, overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' }}>{doc.name}</span>
        </div>
      ))}
    </div>
  );
}

// ─── Tab bar ─────────────────────────────────────────────────────────────── //
function TabBar({ tabs, active, onSelect }) {
  return (
    <div style={{ height: 36, borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'stretch', background: C.elevated, flexShrink: 0, padding: '0 4px' }}>
      {tabs.map(tab => (
        <button key={tab} onClick={() => onSelect(tab)} style={{ background: 'none', border: 'none', borderBottom: `2px solid ${active === tab ? C.accent : 'transparent'}`, padding: '0 14px', cursor: 'pointer', fontFamily: SN, fontSize: 12, color: active === tab ? C.fg1 : C.fg3, fontWeight: active === tab ? 500 : 400, transition: 'color 100ms' }}>{tab}</button>
      ))}
    </div>
  );
}

// ─── Overview tab ─────────────────────────────────────────────────────────── //
function OverviewTab() {
  const stats = [
    { label: 'EV range',     val: '€12.4M – €18.7M', mono: true },
    { label: 'Deal stage',   val: 'Indicative offers' },
    { label: 'Days active',  val: '47' },
    { label: 'Buyers',       val: '6 tracked' },
  ];
  return (
    <div style={{ padding: 20, display: 'flex', flexDirection: 'column', gap: 16 }}>
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 10 }}>
        {stats.map((s, i) => (
          <div key={i} style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 2, padding: '13px 15px' }}>
            <div style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN, marginBottom: 7 }}>{s.label}</div>
            <div style={{ fontFamily: s.mono ? MN : SN, fontSize: s.mono ? 13 : 15, fontWeight: 500, color: C.fg1 }}>{s.val}</div>
          </div>
        ))}
      </div>
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 10 }}>
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 2, padding: '14px 18px' }}>
          <div style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN, marginBottom: 12 }}>Recent AI activity</div>
          {AI_LOG.map((e, i) => (
            <div key={i} style={{ display: 'flex', gap: 10, paddingBottom: i < AI_LOG.length - 1 ? 9 : 0, marginBottom: i < AI_LOG.length - 1 ? 9 : 0, borderBottom: i < AI_LOG.length - 1 ? `1px solid ${C.borderSubtle}` : 'none' }}>
              <span style={{ fontFamily: MN, fontSize: 10, color: C.fg4, width: 36, flexShrink: 0 }}>{e.time}</span>
              <div>
                <div style={{ fontFamily: MN, fontSize: 11, color: C.accentFg, marginBottom: 1 }}>{e.cmd}</div>
                <div style={{ fontFamily: SN, fontSize: 11, color: C.fg3 }}>{e.result}</div>
              </div>
            </div>
          ))}
        </div>
        <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 2, padding: '14px 18px' }}>
          <div style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN, marginBottom: 12 }}>Valuation summary</div>
          {[
            { m: 'DCF',              r: '€15.8M – €17.4M', c: C.greenFg },
            { m: 'Trading comps',    r: '€13.1M – €15.9M', c: C.fg1 },
            { m: 'Precedent M&A',   r: '€14.0M – €18.0M', c: C.fg1 },
            { m: 'Management case', r: '€11.2M – €13.8M', c: C.redFg },
            { m: 'Recommended',     r: '€14.2M – €18.7M', c: C.accentFg },
          ].map((v, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderBottom: i < 4 ? `1px solid ${C.borderSubtle}` : 'none', alignItems: 'baseline' }}>
              <span style={{ fontSize: 11, fontFamily: SN, color: i === 4 ? C.fg1 : C.fg3, fontWeight: i === 4 ? 500 : 400 }}>{v.m}</span>
              <span style={{ fontFamily: MN, fontSize: 11, color: v.c, fontWeight: i === 4 ? 500 : 400 }}>{v.r}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Buyers tab ───────────────────────────────────────────────────────────── //
function BuyersTab() {
  return (
    <div style={{ padding: '14px 20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <div style={{ position: 'relative' }}>
            <input placeholder="Search buyers…" style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 2, fontFamily: SN, fontSize: 12, color: C.fg1, padding: '5px 10px 5px 28px', outline: 'none', width: 190 }} />
            <svg style={{ position: 'absolute', left: 8, top: '50%', transform: 'translateY(-50%)', color: C.fg4 }} width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          </div>
          <span style={{ fontSize: 11, color: C.fg4, fontFamily: SN }}>6 targets</span>
        </div>
        <button style={{ background: C.accent, color: C.bg, border: 'none', fontFamily: SN, fontSize: 11, fontWeight: 500, padding: '5px 12px', borderRadius: 2, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14"/></svg>
          Add buyer
        </button>
      </div>
      <table style={{ width: '100%', borderCollapse: 'collapse', border: `1px solid ${C.border}` }}>
        <thead>
          <tr style={{ background: C.bg }}>
            {['Company', 'Country', 'Type', 'EV', 'Status', 'Last contact'].map(h => (
              <th key={h} style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, padding: '7px 12px', textAlign: 'left', borderBottom: `1px solid ${C.border}`, whiteSpace: 'nowrap' }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {BUYERS.map((b, i) => (
            <tr key={i} style={{ borderBottom: i < BUYERS.length - 1 ? `1px solid ${C.borderSubtle}` : 'none', cursor: 'pointer' }}>
              <td style={{ fontFamily: SN, fontSize: 12, color: C.fg1, fontWeight: 500, padding: '8px 12px' }}>{b.name}</td>
              <td style={{ fontFamily: MN, fontSize: 11, color: C.fg3, padding: '8px 12px' }}>{b.country}</td>
              <td style={{ fontFamily: SN, fontSize: 12, color: C.fg2, padding: '8px 12px' }}>{b.type}</td>
              <td style={{ fontFamily: MN, fontSize: 12, color: C.fg2, padding: '8px 12px' }}>{b.ev}</td>
              <td style={{ padding: '8px 12px' }}><Badge status={b.status} /></td>
              <td style={{ fontFamily: SN, fontSize: 11, color: C.fg4, padding: '8px 12px' }}>{b.last}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

// ─── Documents tab ────────────────────────────────────────────────────────── //
function DocumentsTab() {
  return (
    <div style={{ padding: '14px 20px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
        <span style={{ fontSize: 11, color: C.fg4, fontFamily: SN }}>6 files</span>
        <button style={{ background: C.accent, color: C.bg, border: 'none', fontFamily: SN, fontSize: 11, fontWeight: 500, padding: '5px 12px', borderRadius: 2, cursor: 'pointer', display: 'flex', alignItems: 'center', gap: 5 }}>
          <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M12 5v14M5 12h14"/></svg>
          Generate document
        </button>
      </div>
      <div style={{ border: `1px solid ${C.border}`, borderRadius: 2, overflow: 'hidden' }}>
        <div style={{ display: 'grid', gridTemplateColumns: '3fr 80px 90px 80px', background: C.bg, padding: '7px 16px', borderBottom: `1px solid ${C.border}` }}>
          {['File', 'Type', 'Status', 'Updated'].map(h => (
            <div key={h} style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN }}>{h}</div>
          ))}
        </div>
        {DOCS.map((doc, i) => (
          <div key={i} style={{ display: 'grid', gridTemplateColumns: '3fr 80px 90px 80px', padding: '9px 16px', alignItems: 'center', borderBottom: i < DOCS.length - 1 ? `1px solid ${C.borderSubtle}` : 'none', cursor: 'pointer' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 9 }}>
              <FileIcon color={C.fg4} />
              <div>
                <div style={{ fontFamily: SN, fontSize: 12, color: C.fg1, fontWeight: 500 }}>{doc.name}</div>
                <div style={{ fontFamily: SN, fontSize: 10, color: C.fg4, marginTop: 1 }}>{doc.meta}</div>
              </div>
            </div>
            <div>
              <span style={{ fontFamily: MN, fontSize: 10, fontWeight: 500, padding: '1px 5px', borderRadius: 2, background: C.subtle, color: C.fg3, textTransform: 'uppercase', letterSpacing: '0.04em' }}>{doc.ext}</span>
            </div>
            <div><DocBadge status={doc.status} /></div>
            <div style={{ fontFamily: SN, fontSize: 11, color: C.fg4 }}>{doc.time}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Valuation tab ────────────────────────────────────────────────────────── //
function ValuationTab() {
  const methods = [
    { name: 'DCF',             low: 15.8, high: 17.4, color: C.greenFg },
    { name: 'Trading comps',   low: 13.1, high: 15.9, color: C.blueFg },
    { name: 'Precedent M&A',  low: 14.0, high: 18.0, color: C.accentFg },
    { name: 'Mgmt case',       low: 11.2, high: 13.8, color: C.redFg },
  ];
  const [min, max] = [10, 20];
  const pct = v => ((v - min) / (max - min)) * 100;
  return (
    <div style={{ padding: '16px 20px', display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 16 }}>
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 2, padding: '18px 20px' }}>
        <div style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN, marginBottom: 18 }}>Valuation bridge (€M)</div>
        {methods.map((m, i) => (
          <div key={i} style={{ marginBottom: 16 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 6 }}>
              <span style={{ fontFamily: SN, fontSize: 12, color: C.fg2 }}>{m.name}</span>
              <span style={{ fontFamily: MN, fontSize: 12, color: m.color }}>€{m.low}M – €{m.high}M</span>
            </div>
            <div style={{ position: 'relative', height: 5, background: C.subtle }}>
              <div style={{ position: 'absolute', top: 0, height: '100%', left: `${pct(m.low)}%`, width: `${pct(m.high) - pct(m.low)}%`, background: m.color, opacity: 0.65 }} />
            </div>
          </div>
        ))}
        <div style={{ marginTop: 8, paddingTop: 14, borderTop: `1px solid ${C.borderSubtle}`, display: 'flex', justifyContent: 'space-between' }}>
          <span style={{ fontFamily: SN, fontSize: 12, color: C.fg1, fontWeight: 500 }}>Recommended</span>
          <span style={{ fontFamily: MN, fontSize: 13, color: C.accentFg, fontWeight: 500 }}>€14.2M – €18.7M</span>
        </div>
      </div>
      <div style={{ background: C.surface, border: `1px solid ${C.border}`, borderRadius: 2, padding: '18px 20px' }}>
        <div style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN, marginBottom: 14 }}>Key assumptions</div>
        {[['Revenue FY2025','€28.6M'],['EBITDA FY2025','€3.4M'],['EBITDA margin','11.9%'],['EV/EBITDA range','3.5× – 5.5×'],['WACC (DCF)','9.2%'],['Terminal growth','2.0%'],['Net debt','€2.1M']].map(([k, v], i, arr) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '7px 0', borderBottom: i < arr.length - 1 ? `1px solid ${C.borderSubtle}` : 'none' }}>
            <span style={{ fontFamily: SN, fontSize: 12, color: C.fg3 }}>{k}</span>
            <span style={{ fontFamily: MN, fontSize: 12, color: C.fg1 }}>{v}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── AI Panel ─────────────────────────────────────────────────────────────── //
function AIPanel() {
  const [input, setInput] = useState('');
  const [log, setLog] = useState(AI_LOG.slice(0, 3));

  const submit = (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    const entry = { time: 'Now', cmd: input, result: 'Processing…', ok: null };
    setLog(prev => [entry, ...prev]);
    setInput('');
    setTimeout(() => setLog(prev => {
      const next = [...prev];
      if (next[0].result === 'Processing…') next[0] = { ...next[0], result: 'Done.', ok: true };
      return next;
    }), 1400);
  };

  return (
    <div style={{ height: 156, borderTop: `1px solid ${C.border}`, background: C.bg, display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
      <div style={{ height: 30, borderBottom: `1px solid ${C.borderSubtle}`, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 16px', flexShrink: 0 }}>
        <span style={{ fontSize: 10, fontWeight: 500, letterSpacing: '0.06em', textTransform: 'uppercase', color: C.fg4, fontFamily: SN }}>AI Output</span>
        <button onClick={() => setLog([])} style={{ background: 'none', border: 'none', fontSize: 10, color: C.fg4, cursor: 'pointer', fontFamily: SN }}>Clear</button>
      </div>
      <div style={{ flex: 1, overflowY: 'auto', padding: '6px 16px', display: 'flex', flexDirection: 'column', gap: 3 }}>
        {log.map((e, i) => (
          <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'baseline' }}>
            <span style={{ fontFamily: MN, fontSize: 10, color: C.fg4, width: 36, flexShrink: 0 }}>{e.time}</span>
            <span style={{ fontFamily: MN, fontSize: 11, color: C.accentFg }}>{e.cmd}</span>
            <span style={{ fontFamily: MN, fontSize: 11, color: e.ok === null ? C.yellowFg : e.ok ? C.greenFg : C.redFg }}>{e.result}</span>
          </div>
        ))}
      </div>
      <form onSubmit={submit} style={{ borderTop: `1px solid ${C.borderSubtle}`, display: 'flex', alignItems: 'center', padding: '0 12px', height: 32, flexShrink: 0 }}>
        <span style={{ fontFamily: MN, fontSize: 11, color: C.accentFg, marginRight: 8 }}>arclen&gt;</span>
        <input value={input} onChange={e => setInput(e.target.value)} placeholder="exec pitch-book --deal=alpine" style={{ flex: 1, background: 'transparent', border: 'none', outline: 'none', fontFamily: MN, fontSize: 11, color: C.fg1 }} />
      </form>
    </div>
  );
}

// ─── Status bar ───────────────────────────────────────────────────────────── //
function StatusBar({ deal }) {
  const items = [deal.name, `Stage: ${deal.stage}`, '6 buyers tracked', 'Arclen v2.1.0', 'EU · Frankfurt'];
  return (
    <div style={{ height: 24, background: C.accentSubtle, borderTop: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', padding: '0 12px', gap: 0, flexShrink: 0 }}>
      {items.map((item, i) => (
        <span key={i} style={{ fontFamily: SN, fontSize: 10, color: C.accentFg, padding: '0 8px', borderRight: i < items.length - 1 ? `1px solid #0E2A2E` : 'none' }}>{item}</span>
      ))}
    </div>
  );
}

// ─── App root ─────────────────────────────────────────────────────────────── //
function AppKit() {
  const [activeDeal, setActiveDeal] = useState('alpine');
  const [activeTab, setActiveTab] = useState('Overview');
  const deal = DEALS.find(d => d.id === activeDeal) || DEALS[0];
  const tabs = ['Overview', 'Buyers', 'Documents', 'Valuation'];

  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: C.bg, overflow: 'hidden', fontFamily: SN }}>
      <style>{`* { box-sizing: border-box; margin: 0; padding: 0; } body { background: ${C.bg}; -webkit-font-smoothing: antialiased; } ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 2px; }`}</style>
      <AppNav deal={deal} />
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <AppSidebar activeDeal={activeDeal} onSelect={id => { setActiveDeal(id); setActiveTab('Overview'); }} />
        <div style={{ flex: 1, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <TabBar tabs={tabs} active={activeTab} onSelect={setActiveTab} />
          <div style={{ flex: 1, overflowY: 'auto', background: C.bg }}>
            {activeTab === 'Overview'   && <OverviewTab />}
            {activeTab === 'Buyers'     && <BuyersTab />}
            {activeTab === 'Documents'  && <DocumentsTab />}
            {activeTab === 'Valuation'  && <ValuationTab />}
          </div>
          <AIPanel />
        </div>
      </div>
      <StatusBar deal={deal} />
    </div>
  );
}

Object.assign(window, { AppKit });
