// Arclen IDE Welcome — VS Codium fork chrome for financiers
// Same layout as VS Code, but: deal vocabulary, finance menus & icons, Arctic accent.

const { useState } = React;

const C = {
  bg: '#09090B', surface: '#111116', elevated: '#18181F', subtle: '#1F1F28', inset: '#06060A',
  border: '#27272F', borderSubtle: '#1C1C24', borderStrong: '#3A3A46',
  fg1: '#F0EEE9', fg2: '#8C8A99', fg3: '#50505A', fg4: '#35353E',
  accent: '#5AB8C4', accentHover: '#46A4B0', accentFg: '#7ACCD4', accentSubtle: '#081618', accentMuted: '#3A8A94',
  green: '#4EA87A', greenFg: '#5EBF8D', greenSubtle: '#0B1F15',
  blue: '#5B8FD4', blueFg: '#7AAAE0',
};
const ED = "'Instrument Sans', system-ui, sans-serif";
const SN = "'IBM Plex Sans', system-ui, sans-serif";
const MN = "'IBM Plex Mono', monospace";

// ─── Icons (Lucide-style, 1.5px stroke) ──────────────────────────────────── //
const I = {
  briefcase: <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="2" y="7" width="20" height="14" rx="1"/><path d="M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>,
  search:    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>,
  users:     <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>,
  file:      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/></svg>,
  chart:     <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M3 3v18h18"/><path d="M7 14l4-4 4 4 6-6"/></svg>,
  book:      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"/><path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"/></svg>,
  sparkle:   <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 3l1.9 5.5L19 10l-5.1 1.5L12 17l-1.9-5.5L5 10l5.1-1.5z"/><path d="M19 17l.6 1.8L21 19l-1.4.2L19 21l-.6-1.8L17 19l1.4-.2z"/></svg>,
  user:      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>,
  cog:       <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
  layout:    <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="1"/><path d="M9 3v18"/></svg>,
  panel:     <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><rect x="3" y="3" width="18" height="18" rx="1"/><path d="M3 15h18"/></svg>,
  caret:     <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><polyline points="9 18 15 12 9 6"/></svg>,
  hex:       <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5"><path d="M12 2L3 7v10l9 5 9-5V7l-9-5z"/></svg>,
};

// ─── Title bar ──────────────────────────────────────────────────────────── //
function TitleBar() {
  const menus = ['File', 'Edit', 'Deal', 'View', 'Build', 'Process', 'Help'];
  const [openMenu, setOpenMenu] = useState(null);
  return (
    <div style={{ height: 34, background: C.elevated, borderBottom: `1px solid ${C.border}`, display: 'flex', alignItems: 'stretch', flexShrink: 0, fontFamily: SN, fontSize: 12 }}>
      {/* App icon */}
      <div style={{ width: 44, display: 'flex', alignItems: 'center', justifyContent: 'center', borderRight: `1px solid ${C.borderSubtle}` }}>
        <img src="../../assets/favicon-white-180x180.svg" style={{ width: 16, height: 16, opacity: 0.85 }} alt="" />
      </div>
      {/* Menu items */}
      <div style={{ display: 'flex', alignItems: 'stretch' }}>
        {menus.map(m => (
          <div key={m} onClick={() => setOpenMenu(openMenu === m ? null : m)} style={{
            display: 'flex', alignItems: 'center', padding: '0 11px', cursor: 'default',
            color: openMenu === m ? C.fg1 : C.fg2,
            background: openMenu === m ? C.subtle : 'transparent',
          }}>{m}</div>
        ))}
      </div>
      {/* Centered title */}
      <div style={{ flex: 1, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        <span style={{ color: C.fg3 }}>Arclen</span>
      </div>
      {/* Right side: layout controls + window controls */}
      <div style={{ display: 'flex', alignItems: 'center', padding: '0 12px', gap: 12, color: C.fg3 }}>
        <span style={{ cursor: 'pointer' }}>{I.layout}</span>
        <span style={{ cursor: 'pointer' }}>{I.panel}</span>
        <div style={{ display: 'flex', gap: 7, marginLeft: 4 }}>
          {['#FF5F57', '#FEBC2E', '#28C840'].map((c, i) => (
            <div key={i} style={{ width: 11, height: 11, borderRadius: '50%', background: c, opacity: 0.95 }} />
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Activity Bar (left vertical icon strip) ─────────────────────────────── //
function ActivityBar({ active, onSelect }) {
  const top = [
    { id: 'deals',    icon: I.briefcase, label: 'Deals' },
    { id: 'search',   icon: I.search,    label: 'Search' },
    { id: 'buyers',   icon: I.users,     label: 'Buyers' },
    { id: 'docs',     icon: I.file,      label: 'Documents' },
    { id: 'val',      icon: I.chart,     label: 'Valuation' },
    { id: 'tpl',      icon: I.book,      label: 'Templates' },
    { id: 'ai',       icon: I.sparkle,   label: 'AI' },
  ];
  const bottom = [
    { id: 'account',  icon: I.user, label: 'Account' },
    { id: 'settings', icon: I.cog,  label: 'Settings' },
  ];
  const Item = ({ item }) => (
    <div onClick={() => onSelect(item.id)} title={item.label} style={{
      height: 48, display: 'flex', alignItems: 'center', justifyContent: 'center',
      cursor: 'pointer', position: 'relative',
      color: active === item.id ? C.fg1 : C.fg3,
      transition: 'color 100ms',
    }}>
      {active === item.id && <div style={{ position: 'absolute', left: 0, top: 8, bottom: 8, width: 2, background: C.accent }} />}
      {item.icon}
    </div>
  );
  return (
    <div style={{ width: 48, background: C.bg, borderRight: `1px solid ${C.borderSubtle}`, display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
      <div style={{ flex: 1 }}>{top.map(item => <Item key={item.id} item={item} />)}</div>
      <div>{bottom.map(item => <Item key={item.id} item={item} />)}</div>
    </div>
  );
}

// ─── Deals Sidebar Panel (when no deal opened) ───────────────────────────── //
function DealsSidebar({ onOpenDeal }) {
  const recent = [
    { name: 'Project Alpine',  stage: 'IOI · 23 buyers',    color: C.accent },
    { name: 'Project Rhine',   stage: 'Preparation',         color: C.blue },
    { name: 'Project Elbe',    stage: 'Signed · 4 weeks ago', color: C.green },
    { name: 'Project Danube',  stage: 'Closed · Q1 2026',    color: C.fg4 },
  ];
  return (
    <div style={{ width: 240, background: C.surface, borderRight: `1px solid ${C.border}`, display: 'flex', flexDirection: 'column', flexShrink: 0, overflow: 'hidden' }}>
      {/* Panel header */}
      <div style={{ height: 34, display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '0 14px 0 16px', borderBottom: `1px solid ${C.borderSubtle}` }}>
        <span style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase', color: C.fg3 }}>Deals</span>
        <span style={{ color: C.fg3, cursor: 'pointer', fontSize: 14, lineHeight: 1 }}>···</span>
      </div>
      {/* Empty state body */}
      <div style={{ padding: 14, display: 'flex', flexDirection: 'column', gap: 16 }}>
        <p style={{ fontFamily: SN, fontSize: 12, lineHeight: 1.55, color: C.fg2, margin: 0 }}>
          You have not yet opened a deal folder.
        </p>
        <button onClick={onOpenDeal} style={{ background: C.accent, color: C.bg, border: 'none', fontFamily: SN, fontSize: 12, fontWeight: 500, padding: '7px 12px', borderRadius: 2, cursor: 'pointer' }}>
          Open deal
        </button>
        <button style={{ background: 'transparent', color: C.fg2, border: `1px solid ${C.border}`, fontFamily: SN, fontSize: 12, padding: '7px 12px', borderRadius: 2, cursor: 'pointer' }}>
          New deal
        </button>
      </div>

      {/* Recent */}
      <div style={{ padding: '14px 14px 6px', borderTop: `1px solid ${C.borderSubtle}`, marginTop: 8 }}>
        <span style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase', color: C.fg4 }}>Recent</span>
      </div>
      <div style={{ flex: 1, overflowY: 'auto' }}>
        {recent.map((d, i) => (
          <div key={i} style={{ height: 38, display: 'flex', alignItems: 'center', gap: 9, padding: '0 14px', cursor: 'pointer' }}
               onMouseEnter={e => e.currentTarget.style.background = C.subtle}
               onMouseLeave={e => e.currentTarget.style.background = 'transparent'}>
            <div style={{ width: 6, height: 6, borderRadius: '50%', background: d.color, flexShrink: 0 }} />
            <div style={{ overflow: 'hidden' }}>
              <div style={{ fontFamily: SN, fontSize: 12, color: C.fg1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{d.name}</div>
              <div style={{ fontFamily: SN, fontSize: 10.5, color: C.fg4, marginTop: 1, whiteSpace: 'nowrap', overflow: 'hidden', textOverflow: 'ellipsis' }}>{d.stage}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Welcome view (main editor area) ─────────────────────────────────────── //
function WelcomeView() {
  const Shortcut = ({ keys }) => (
    <div style={{ display: 'flex', gap: 5 }}>
      {keys.map((k, i) => (
        <React.Fragment key={i}>
          <kbd style={{ fontFamily: MN, fontSize: 10, background: C.inset, border: `1px solid ${C.border}`, borderRadius: 2, padding: '2px 6px', color: C.fg2, minWidth: 22, textAlign: 'center', boxShadow: `0 1px 0 ${C.borderSubtle}` }}>{k}</kbd>
          {i < keys.length - 1 && <span style={{ color: C.fg4, fontSize: 10, alignSelf: 'center' }}>+</span>}
        </React.Fragment>
      ))}
    </div>
  );
  const actions = [
    { label: 'Open AI panel',      keys: ['Ctrl', 'Alt', 'I'] },
    { label: 'Show all commands',  keys: ['Ctrl', 'Shift', 'P'] },
    { label: 'Open recent deal',   keys: ['Ctrl', 'R'] },
    { label: 'Open deal',          keys: ['Ctrl', 'O'] },
    { label: 'New deal',           keys: ['Ctrl', 'Shift', 'N'] },
    { label: 'Build pitch book',   keys: ['Ctrl', 'B'] },
  ];

  return (
    <div style={{ flex: 1, background: C.bg, position: 'relative', overflow: 'hidden' }}>
      {/* Big watermark mark — Arclen ▽ */}
      <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -52%)', pointerEvents: 'none', opacity: 0.06 }}>
        <img src="../../assets/favicon-white-180x180.svg" style={{ width: 340, height: 340 }} alt="" />
      </div>

      {/* Top-left: small intro */}
      <div style={{ position: 'absolute', top: 40, left: 56, maxWidth: 420 }}>
        <div style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, letterSpacing: '0.12em', textTransform: 'uppercase', color: C.fg4, marginBottom: 12 }}>Arclen · v2.1.0</div>
        <h1 style={{ fontFamily: ED, fontSize: 32, fontWeight: 600, letterSpacing: '-0.025em', color: C.fg1, lineHeight: 1.1, margin: 0 }}>
          Open a deal to begin.
        </h1>
        <p style={{ fontFamily: SN, fontSize: 13.5, lineHeight: 1.7, color: C.fg2, marginTop: 14, marginBottom: 0 }}>
          Point Arclen at a deal folder and it will index the files, parse the model, and identify the stage. Or start a new mandate from a firm template.
        </p>
      </div>

      {/* Bottom-right: keyboard shortcuts (matches VS Code reference layout) */}
      <div style={{ position: 'absolute', bottom: 48, right: 56, display: 'flex', flexDirection: 'column', gap: 12 }}>
        {actions.map((a, i) => (
          <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 18, justifyContent: 'flex-end' }}>
            <span style={{ fontFamily: SN, fontSize: 13, color: C.fg2 }}>{a.label}</span>
            <Shortcut keys={a.keys} />
          </div>
        ))}
      </div>

      {/* Bottom-left: tip / quick start */}
      <div style={{ position: 'absolute', bottom: 48, left: 56, maxWidth: 360 }}>
        <div style={{ background: C.surface, border: `1px solid ${C.borderSubtle}`, borderLeft: `2px solid ${C.accent}`, borderRadius: 2, padding: '14px 16px' }}>
          <div style={{ fontFamily: SN, fontSize: 10, fontWeight: 500, letterSpacing: '0.08em', textTransform: 'uppercase', color: C.accentFg, marginBottom: 8 }}>Tip</div>
          <p style={{ fontFamily: SN, fontSize: 12.5, lineHeight: 1.65, color: C.fg2, margin: 0 }}>
            Try <kbd style={{ fontFamily: MN, fontSize: 11, background: C.inset, border: `1px solid ${C.border}`, borderRadius: 2, padding: '1px 5px', color: C.fg1 }}>⌘ K</kbd> to open the command palette. Type a deal name, file, or task — Arclen will route to the right action.
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── Status bar ──────────────────────────────────────────────────────────── //
function StatusBar() {
  return (
    <div style={{ height: 24, background: C.accentSubtle, borderTop: `1px solid ${C.border}`, display: 'flex', alignItems: 'center', flexShrink: 0, fontFamily: SN, fontSize: 10.5 }}>
      <div style={{ display: 'flex', alignItems: 'center', padding: '0 10px', color: C.accentFg, gap: 6 }}>
        <span style={{ width: 6, height: 6, borderRadius: '50%', background: C.greenFg }} />
        Ready
      </div>
      {['No deal opened', 'Claude · 387K tokens'].map((t, i) => (
        <div key={i} style={{ padding: '0 10px', color: C.accentFg, borderLeft: `1px solid ${C.accentMuted}40` }}>{t}</div>
      ))}
      <div style={{ flex: 1 }} />
      {['Excel · ready', 'PowerPoint · ready', 'Word · ready', 'EU · Frankfurt', 'v2.1.0'].map((t, i) => (
        <div key={i} style={{ padding: '0 10px', color: C.accentFg, borderLeft: `1px solid ${C.accentMuted}40` }}>{t}</div>
      ))}
    </div>
  );
}

// ─── Welcome root ────────────────────────────────────────────────────────── //
function IDEWelcome() {
  const [active, setActive] = useState('deals');
  return (
    <div style={{ height: '100vh', display: 'flex', flexDirection: 'column', background: C.bg, overflow: 'hidden', fontFamily: SN }}>
      <style>{`* { box-sizing: border-box; margin: 0; padding: 0; } body { background: ${C.bg}; -webkit-font-smoothing: antialiased; } ::-webkit-scrollbar { width: 6px; } ::-webkit-scrollbar-track { background: transparent; } ::-webkit-scrollbar-thumb { background: ${C.border}; border-radius: 2px; }`}</style>
      <TitleBar />
      <div style={{ flex: 1, display: 'flex', overflow: 'hidden' }}>
        <ActivityBar active={active} onSelect={setActive} />
        <DealsSidebar onOpenDeal={() => alert('Open deal folder picker')} />
        <WelcomeView />
      </div>
      <StatusBar />
    </div>
  );
}

Object.assign(window, { IDEWelcome });
