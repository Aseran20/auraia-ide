# Arclen App UI Kit

Deal execution interface — VS Code webview / standalone web app.

## What's here
- `index.html` — Entry point, loads React + Babel + fonts
- `components.jsx` — All UI components as React

## Views implemented
- **AppNav** — Top bar: breadcrumb (Arclen / deal name / stage), Run button, New document, Settings
- **AppSidebar** — Deal list (4 deals with status dots) + file shortcuts
- **TabBar** — Overview / Buyers / Documents / Valuation tabs with arctic active indicator
- **OverviewTab** — 4 stat cards + Recent AI activity log + Valuation summary
- **BuyersTab** — Searchable buyer universe table with status badges
- **DocumentsTab** — File list with type, status, and last-updated columns
- **ValuationTab** — Valuation bridge chart + key assumptions table
- **AIPanel** — Collapsible bottom panel: command log + interactive `arclen>` input
- **StatusBar** — Arctic-tinted status bar with deal context

## Interactions
- Click deals in sidebar to switch (all tabs reset to Overview)
- Click tabs to navigate between views
- Type in `arclen>` and press Enter to simulate AI command execution
- Click "Clear" in AI panel to reset log

## Design notes
- Full-height viewport application (`100vh`), overflow hidden.
- IBM Plex Sans for all UI text; IBM Plex Mono for data values, commands, paths.
- Color system: `#09090B` base, `#111116` surface, `#18181F` elevated.
- Arctic accent (`#5AB8C4`) for primary actions, active states, status bar.
- 1px borders only; no shadows on surfaces; depth via layered opaque backgrounds.

## Assets used
- `../../assets/favicon-white-180x180.svg` — Small nav icon
