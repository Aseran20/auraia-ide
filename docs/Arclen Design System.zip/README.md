# Arclen Design System

## Overview

**Arclen** is an AI-powered M&A workflow platform built as a **fork of VS Codium**, specifically designed for boutique investment banks. Rather than a plugin or extension, Arclen is a purpose-built IDE for finance — taking the open-source VS Codium base and reshaping it into a full deal execution environment.

The core idea: bring Claude Code and M&A workflows into a single environment, with deep native integrations for Excel, PowerPoint, and Word via COM automation. The banker stays inside their Office files; Arclen operates them in real-time. No generated files, no black box, no copy-pasting between tools.

**What it automates:** pitch books, financial datapacks, buyer outreach lists, valuation comps, process letters, NDA tracking — all as live operations on the banker's existing documents.

**Target market:** Investment bankers advising on €5–200M transactions at boutique advisory firms across Europe.

**Surfaces:** VS Codium IDE (primary), arclen.app marketing site, PowerPoint decks, Excel datapacks, Word documents, PDF exports.

---

## Source Materials

The following assets were provided for this design system:

- `uploads/logo-white.svg` — Full wordmark, white (for dark backgrounds)
- `uploads/logo-black.svg` — Full wordmark, black (for light backgrounds)
- `uploads/favicon-white-180x180.svg` — Favicon: white triangle on black circle
- `uploads/favicon-black-180x180.svg` — Favicon: black triangle on white circle

No Figma links or codebase repositories were provided. The design system has been constructed from the supplied logo assets and the written brand brief.

---

## Brand Positioning

> Premium fintech for M&A advisory. Not a startup SaaS — a professional tools platform used by investment bankers who advise on €5–200M transactions.

Arclen occupies a rare position: the sophistication of a top-tier law firm meets the precision of modern developer tooling. It is authoritative, not flashy. Minimal, not sparse. Every design decision should ask: *would a senior banker trust this?*

---

## CONTENT FUNDAMENTALS

### Voice & Tone

**Expert, direct, no fluff.** The tool speaks like a senior banker — precise, confident, never over-explains.

- **Not:** "We help you streamline your M&A workflows with AI-powered automation!"
- **Yes:** "Arclen runs your process. You run the deal."

**Principles:**
1. **Brevity over completeness.** One precise sentence beats two adequate ones.
2. **Active voice, always.** "Arclen builds the pitch book." Not "The pitch book is built by Arclen."
3. **No hedging.** Remove "typically," "usually," "can help," "aims to."
4. **Address the user as "you."** The product is "Arclen" or simply implied. Never "we" in UI copy.
5. **Zero startup vocabulary.** Never: "seamless," "leverage," "unlock," "supercharge," "game-changer," "empower."
6. **Numbers are precise.** Not "fast" — "in under 4 seconds." Not "many clients" — "47 mandates."
7. **Sentence case everywhere.** Headlines, buttons, labels — all sentence case. Only proper nouns capitalized.

### Casing
- **UI labels:** sentence case — `Build pitch book`, not `Build Pitch Book`
- **Document names:** Title Case — `Vendor Due Diligence Report`
- **Error messages:** sentence case, period at end — `File not found.`
- **Buttons:** sentence case, no punctuation — `Run analysis`

### Emoji
No emoji. Ever. The product exists in environments (Excel cells, Word headers, VS Code terminals) where emoji is inappropriate or rendering-unpredictable.

### Copy Examples
- "Your buyers list is ready. 23 targets identified."
- "Valuation range: €12.4M – €18.7M"
- "Process letter sent to 4 counterparties."
- "Missing: EBITDA margin for FY2023."

---

## VISUAL FOUNDATIONS

### Color System

**Dark mode is primary.** The product lives in VS Code (dark theme), runs overnight, and is used by people who associate black screens with control.

| Role | Token | Value |
|---|---|---|
| Page background | `--bg-base` | `#09090B` |
| Surface (panels, cards) | `--bg-surface` | `#111116` |
| Elevated (modals, dropdowns) | `--bg-elevated` | `#18181F` |
| Subtle (hover backgrounds) | `--bg-subtle` | `#1F1F28` |
| Border (default) | `--border` | `#27272F` |
| Border (subtle) | `--border-subtle` | `#1C1C24` |
| Primary text | `--fg-1` | `#F0EEE9` |
| Secondary text | `--fg-2` | `#8C8A99` |
| Tertiary/disabled | `--fg-3` | `#50505A` |
| **Accent (arctic)** | `--accent` | `#5AB8C4` |
| Accent hover | `--accent-hover` | `#46A4B0` |
| Accent subtle bg | `--accent-subtle` | `#081618` |
| Accent text on dark | `--accent-fg` | `#7ACCD4` |
| Positive/gains | `--green` | `#46A878` |
| Negative/loss | `--red` | `#C2504F` |
| Caution/pending | `--yellow` | `#C99A3C` |
| Info/IOI (indigo) | `--blue` | `#6470C4` |
| Neutral/idle | `--neutral` | `#6E6E7A` |

**Accent rationale:** Arctic — European heritage, premium and precise. Warmer and more restrained than generic fintech amber, closer to aged leather or fine spirits. Legible at 8pt in Excel; holds on 11px uppercase labels on dark surfaces.

### Typography

**Display / Headlines:** Instrument Sans — geometric, slightly condensed, authoritative. Sharp but not cold.
**Body / UI:** IBM Plex Sans — bridges financial precision with developer-tooling heritage. Excellent at small sizes. Used for all UI text, body copy, labels.
**Data / Code / Numbers:** IBM Plex Mono — consistent family extension. Used for all data values, file paths, terminal output, financial figures in dense tables.

| Scale | Token | Size | Weight | Tracking |
|---|---|---|---|---|
| Display | `--t-display` | 48px / 3rem | 600 | -0.02em |
| H1 | `--t-h1` | 32px / 2rem | 600 | -0.015em |
| H2 | `--t-h2` | 24px / 1.5rem | 600 | -0.01em |
| H3 | `--t-h3` | 18px / 1.125rem | 500 | -0.005em |
| Body | `--t-body` | 14px / 0.875rem | 400 | 0 |
| Small | `--t-small` | 12px / 0.75rem | 400 | 0.005em |
| Label | `--t-label` | 11px / 0.6875rem | 500 | 0.04em uppercase |
| Mono | `--t-mono` | 13px / 0.8125rem | 400 | 0 |
| Mono small | `--t-mono-sm` | 11px / 0.6875rem | 400 | 0 |

### Spacing & Layout
- Base unit: **4px**. All spacing is multiples of 4.
- Common values: 4, 8, 12, 16, 24, 32, 48, 64, 96, 128
- **Border radius:** 2px (inputs, cards, buttons). Max 4px for modals. No rounded "pill" shapes in UI elements. Sharp corners everywhere.
- **Line height:** 1.5 for body, 1.2 for headings, 1.4 for UI labels

### Backgrounds
- No gradients. No textures. No photography in UI.
- Depth is expressed purely through stacking transparent backgrounds (surface layers).
- Dark panels use `--bg-surface`. Modals use `--bg-elevated`. Side panels float with a single 1px border.

### Animation
- Minimal. Transitions only for state changes (appear/disappear, expand/collapse).
- Easing: `cubic-bezier(0.16, 1, 0.3, 1)` (fast out, slow settle) — authority, not playfulness.
- Duration: 120ms for micro (hover, focus), 200ms for panels/drawers, 0 for data updates.
- No bounce. No spring. No decorative animation.

### Hover & Press States
- **Hover:** background shifts to `--bg-subtle`, text to `--fg-1` if was `--fg-2`
- **Press:** scale(0.985) + 30ms transition — very subtle, not cartoonish
- **Focus:** 1px outline in `--accent` at 1px offset, no shadow rings
- **Disabled:** `--fg-3` text, no cursor change

### Borders & Shadows
- 1px borders only. Never thicker. Color: `--border`.
- No box-shadows in dark mode surfaces — depth from layered opaque backgrounds.
- Minimal use of `drop-shadow`: only for floating elements (tooltips, context menus) using `rgba(0,0,0,0.4)`.
- **No inner shadows.** No inset decorations.

### Cards
- Background: `--bg-surface` or `--bg-elevated`
- Border: 1px solid `--border`
- Border-radius: 2px
- Padding: 16px or 24px
- No outer shadow. No colored accents. No left-border "stripe" patterns.

### Corner Radii
- **2px** — default for all interactive elements (inputs, buttons, dropdowns, cards)
- **4px** — modals, large panels only
- **0px** — tables, code blocks, data cells

### Imagery & Color of Imagery
- No photography in the product UI. Marketing website may use sparse, high-contrast photography.
- If used: cold, desaturated — office environments, deal rooms, document stacks. Black and white preferred. No warm lifestyle photography.

### Transparency & Blur
- Blur is not used in the product UI. It suggests casualness.
- Transparency: surface overlays at max 90% opacity. No frosted glass.

---

## ICONOGRAPHY

The Arclen icon system is not yet published as a dedicated icon set. Current usage:

**Icon approach:** Line icons, 16×16 or 20×20, stroke-weight 1.5px. Stroke style only — no fill icons.
**Recommended library:** [Lucide Icons](https://lucide.dev) — clean, consistent 1.5px stroke, professionally maintained. Matches Arclen's precision aesthetic perfectly.
**Usage:** Icons are always `--fg-2` (muted) by default, shifting to `--fg-1` on hover or when active. The accent color `--accent` is used for icons only when conveying status or primary action.
**No icon fonts.** SVG only — works across Excel COM, VS Code, web.
**Emoji:** Never used.

**Brand mark:** The ▽ (inverted triangle) is Arclen's primary icon. Used as favicon, avatar, and brand identifier. It appears in the logo SVG as an open triangle path (not filled with the word "A"). See `assets/` for SVG files.

---

## File Index

```
/
├── README.md                        ← This file (full design system documentation)
├── SKILL.md                         ← Agent skill definition (Claude Code compatible)
├── colors_and_type.css              ← All CSS custom properties: colors, type scale, spacing,
│                                      animation, z-index. Import this in any project.
│
├── assets/
│   ├── logo-white.svg               ← Full wordmark, white (for dark backgrounds)
│   ├── logo-black.svg               ← Full wordmark, black (for light backgrounds)
│   ├── favicon-white-180x180.svg    ← Favicon: white ▽ on black circle
│   └── favicon-black-180x180.svg    ← Favicon: black ▽ on white circle
│
├── preview/                         ← Design System tab cards (registered assets)
│   │
│   │  — Colors —
│   ├── colors-base.html             ← Backgrounds, borders, foreground text scale
│   ├── colors-accent.html           ← Arctic accent (selected) + 3 alternatives
│   ├── colors-semantic.html         ← Green / Red / Yellow / Blue status colors
│   │
│   │  — Typography —
│   ├── type-scale.html              ← Full type scale: display → mono, tokens + specimens
│   ├── type-specimens.html          ← Instrument Sans / IBM Plex Sans / IBM Plex Mono family specimens
│   │
│   │  — Spacing & Elevation —
│   ├── spacing-tokens.html          ← 4px-base spacing scale with visual bars
│   ├── border-radius.html           ← 0 / 2px / 4px radius system
│   ├── shadows-elevation.html       ← Surface → tooltip → dropdown → modal shadows
│   │
│   │  — Components —
│   ├── buttons.html                 ← Primary / secondary / ghost / destructive / disabled
│   ├── inputs.html                  ← Text input / select / search / error / valid states
│   ├── badges.html                  ← Status tags, deal stage badges, sizes
│   ├── cards.html                   ← Deal card / valuation summary / empty state
│   ├── data-table.html              ← Buyer universe table with status badges + financial data
│   │
│   │  — Brand —
│   └── logo-usage.html              ← Wordmark on all backgrounds + favicon at sizes
│
└── ui_kits/
    ├── website/
    │   ├── README.md                ← Website kit documentation
    │   ├── index.html               ← Marketing landing page (arclen.app)
    │   └── components.jsx           ← NavBar, Hero + TerminalDemo, StatsStrip,
    │                                   FeaturesSection, HowItWorks, CTA, Footer
    └── app/
        ├── README.md                ← App kit documentation
        ├── index.html               ← Deal execution interface (VS Code webview)
        └── components.jsx           ← AppNav, AppSidebar, TabBar, OverviewTab,
                                        BuyersTab, DocumentsTab, ValuationTab,
                                        AIPanel, StatusBar
```

## Quick start for agents

```js
// 1. Import design tokens
<link rel="stylesheet" href="colors_and_type.css">

// 2. Use logo assets
<img src="assets/logo-white.svg">        // on dark backgrounds
<img src="assets/favicon-white-180x180.svg">  // as icon/favicon

// 3. Key values to memorise
//    Background base:    #09090B
//    Surface:            #111116
//    Primary text:       #F0EEE9
//    Secondary text:     #8C8A99
//    Accent (arctic):    #5AB8C4  (button bg, active state)
//    Accent fg:          #7ACCD4  (text links, icon labels)
//    Display font:       Instrument Sans 600, tight letter-spacing
//    Body font:          IBM Plex Sans 400
//    Data/code font:     IBM Plex Mono 400
```
